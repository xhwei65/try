﻿namespace Neo.Compiler
{
    public interface ILogger
    {
        void Log(string log);
    }
}
